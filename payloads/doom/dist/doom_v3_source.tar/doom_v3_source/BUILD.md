# doom_cassette_v3.html — complete corresponding source

This archive is the **complete corresponding source** (GPL-2.0 section 3) for the
DOOM engine binary embedded in `doom_cassette_v3.html` — the single-file,
zero-dependency DOOM (Freedoom Phase 1, Episode 1, with WebAudio sound effects,
localStorage savegames and an attract-demo boot) carried as data on **side A**
of this cassette. This archive is carried as data on **side B** of the same
cassette, encoded with the identical r6 modem (D2X_P21_N256_sp2_drop1,
RS(255,159), net 4910 bps).

Shipped artifact this source corresponds to:

    doom_cassette_v3.html   4,851,786 B raw
    sha256 55390aac96bab0bdd66d22071675b3432e214f54cb61738f7b951ce4bef42aab

## What is in here

    build/src/                  engine sources actually compiled (doomgeneric core,
                                GPL-2.0) incl. build/src/doomgeneric_wasm_v3.c —
                                the v3 WASM backend (framebuffer, input, WebAudio
                                DG_sound_module, savegame mirror hooks)
    build/src_v3/SDL_mixer.h    empty stub satisfying i_sound.c's include
                                (the real backend is doomgeneric_wasm_v3.c)
    build/pre_wad_v3.js         pre-js linked into the engine (--pre-js): serves
                                the IWAD from Module.wadBinary as /doom1.wad and
                                restores/mirrors /savegames <-> localStorage
    build/build_v3.sh           compiles + links pack/doom_pack_v3.{js,wasm}
    build/trim_freedoom_v3.py   builds freedoom_e1_v3.wad from freedoom1.wad
    build/assemble_html_v3.py   emits the final single-file HTML (rawpack carrier)
    build/rawpack.py            windows-1252 raw-byte packer used by assemble
    LICENSES/                   GPL-2.0 (engine) + BSD-3-Clause (Freedoom assets,
                                miniwad stub donor) + Freedoom CREDITS
    BUILD.md                    this file

## Toolchain (exact versions used for the shipped build)

* **Emscripten**: emcc **6.0.0** (`afa15e0c56d1292e073c2c91bafc1d5e0cdf0dd3`),
  installed via emsdk (`emsdk install 6.0.0 && emsdk activate 6.0.0`).
* **Python 3 with the `_lzma` module** for the WAD trim + size report
  (on macOS use `/usr/bin/python3`; a pyenv build without `_lzma` will fail).
* Host used for the shipped build: macOS arm64 (Darwin 25.5.0). The build is
  not host-specific.

## Inputs NOT in this archive (game data, not GPL source — fetch separately)

* `freedoom-0.13.0.zip` — Freedoom 0.13.0 release,
  <https://github.com/freedoom/freedoom/releases/tag/v0.13.0>
  sha256 `3f9b264f3e3ce503b4fb7f6bdcb1f419d93c7b546f4df3e874dd878db9688f59`.
  Unzip and place `freedoom1.wad` at `build/freedoom1.wad`
  (sha256 `7323bcc168c5a45ff10749b339960e98314740a734c30d4b9f3337001f9e703d`).
* `miniwad.wad` — Simon Howard (fragglet), <https://github.com/fragglet/miniwad>,
  prebuilt zip from `https://soulsphere.org/random/miniwad.zip`
  (zip sha256 `b4c9804343be34e485fddab802c18ecf836168d733c2f03441d8a9dff80b2393`,
  wad sha256 `daed5e9dc341a9ff4b9c6901cb8467a630bd31b87f3ecb58a93a8b2bc186fbfb`).
  Place at `build/miniwad/miniwad.wad` (stub-lump donor for the trimmer).

Engine source provenance: `build/src/` is the pristine
[ozkl/doomgeneric](https://github.com/ozkl/doomgeneric) source tree
(upstream HEAD `dcb7a8d`, GPL-2.0) plus the two cassette backends
`doomgeneric_wasm.c` (v1/v2, frozen) and `doomgeneric_wasm_v3.c` (v3, shipped).

## Build steps

From the `build/` directory of this archive:

```sh
# 0. toolchain on PATH
source <emsdk>/emsdk_env.sh          # provides emcc 6.0.0 (see above)

# 1. game data in place (see "Inputs" above)
#    build/freedoom1.wad  +  build/miniwad/miniwad.wad

# 2. the v3 WAD slice — defaults reproduce the SHIP config exactly:
#    --maps E1M1..E1M9 --tex-budget 70 --flat-budget 60 --sprite-mode front
#    --sfx-mode real --sfx-rate-cap 11025 --sfx-alias-level 8 --demos real
/usr/bin/python3 trim_freedoom_v3.py
#    -> freedoom_e1_v3.wad   (RAW ~4482 KB, lzma9 ~1394 KB)

# 3. the engine pack (compile + link, -DFEATURE_SOUND, closure, pre_wad_v3.js)
./build_v3.sh
#    -> pack/doom_pack_v3.js + pack/doom_pack_v3.wasm

# 4. the single-file artifact
mkdir -p ../dist
/usr/bin/python3 assemble_html_v3.py
#    -> ../dist/doom_cassette_v3.html
```

Open `doom_cassette_v3.html` in any modern browser (works on `file://`).
Click **INSERT TAPE & PLAY** — the click is the user gesture that resumes the
WebAudio AudioContext. F2/F3 (or the in-game menu) save/load; saves persist
across page reloads via localStorage.

## Licenses

* **Engine** (`build/src/`, `doomgeneric_wasm_v3.c`, build/assembly scripts):
  GPL-2.0 — `LICENSES/doomgeneric.GPL-2.0.txt`.
* **Freedoom assets** (everything in `freedoom_e1_v3.wad` derived from
  `freedoom1.wad`): BSD 3-Clause —
  `LICENSES/freedoom.COPYING.BSD-3-Clause.txt` (+ `freedoom.CREDITS.txt`).
  The Freedoom name must not be used to endorse derived products.
* **miniwad** (stub-lump donor): BSD 3-Clause —
  `LICENSES/miniwad.COPYING.BSD-3-Clause.adoc`.

No proprietary or shareware id Software content anywhere in the chain.
